import pygame

class Gun:
    def __init__(self, player,map):
        self.player = player
        self.map = map
    
    def shoot(self):
        ray = Ray(rayAngle,self.player,self.map)
        endpoint = ray.cast()
        
        #clipped_line = my_rect.clipline(line_colliding)