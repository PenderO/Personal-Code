import pygame
from settings import *
from map import Map
from player import Player
from raycaster import Raycaster
from keyhandler import Keyhandler
from shade import Shade

screen = pygame.display.set_mode((WINDOW_WIDTH*scale_constant, WINDOW_HEIGHT*scale_constant))
canvas = pygame.Surface((WINDOW_WIDTH,WINDOW_HEIGHT))

map = Map()
player = Player(map)
raycaster = Raycaster(player,map)
keyhandler = Keyhandler()
shade = Shade()

clock = pygame.time.Clock()

while True:
    clock.tick(60)
    
    scroll[0] += (player.x-scroll[0]-WINDOW_WIDTH/2)/50
    scroll[1] += (player.y-scroll[1]-WINDOW_HEIGHT/2)/50
    kdlist = []
    kulist = []
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        
        if event.type == pygame.KEYDOWN:
            kdlist = keyhandler.readkeydown(event)
            
        if event.type == pygame.KEYUP:
            kulist = keyhandler.readkeyup(event)
    player.update(kulist,kdlist)

    endpoints = raycaster.castAllRays()

    
    canvas.fill((0,0,0))
    
    map.render(canvas)
    player.render(canvas)
    shade.rendershade(canvas,endpoints,player.x,player.y,scroll)
    
    scaled_surf = pygame.transform.scale(canvas,(WINDOW_WIDTH*scale_constant, WINDOW_HEIGHT*scale_constant))
    screen.blit(scaled_surf, (0, 0))

    pygame.display.update()