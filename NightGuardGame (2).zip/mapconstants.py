from utilities import *


TILESIZE = 32

game_map = other_load_map('mapfile')

COLS = 0
for i in range(len(game_map)):
    for j in range(len(game_map[i])):
        game_map[i][j] = int(game_map[i][j])
ROWS = len(game_map)
COLS = len(game_map[0])

MAP_LIMIT_X = COLS * TILESIZE
MAP_LIMIT_Y = ROWS * TILESIZE

global scale_constant
scale_constant = 1.75