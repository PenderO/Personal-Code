import math, pygame

def other_load_map(path):
    f = open(path + '.txt','r')
    data = f.read()
    f.close()
    data = data.split()
    game_map = []
    for row in data:
        row = [int(item) for item in row]
        game_map.append(list(row))
    return game_map
    
def rotate_img(surface,image,angle,x,y):
    image_copy = pygame.transform.rotate(image,angle)
    return(image_copy,(x-int(image_copy.get_width()/2),y-int(image_copy.get_height()/2)))

def normalizeAngle(angle):
    angle = angle%(2*math.pi)
    if (angle <= 0):
        angle = (2*math.pi)+angle
    return angle

def normalizeDegree(angle):
    angle = angle%(360)
    if (angle <= 0):
        angle = (360)+angle
    return angle


def distance_between(x1,y1,x2,y2):
    return math.sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1))