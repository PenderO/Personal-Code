import pygame

class Animations:
    def __init__(self):
        global animation_frames
        animation_frames = {}
        self.animation_database = {}
        
    def load_animation(self,path,frame_durations):
        global animation_frames
        animation_name = path.split('/')[-1]
        animation_frame_data = []
        n = 0
        for frame in frame_durations:
            animation_frame_id = animation_name + '_' + str(n)
            img_loc = path + '/' + animation_frame_id + '.png'
            animation_image = pygame.image.load(img_loc).convert_alpha()
            animation_frames[animation_frame_id] = animation_image.copy()
            for i in range(frame):
                animation_frame_data.append(animation_frame_id)
            n += 1
        return animation_frame_data
        
    def change_action(self,action_var,frame,new_value):
        if action_var != new_value:
            action_var = new_value
            frame = 0
        return action_var,frame
    
    def init_animation(self):
        self.animation_database['GIdleBottom'] = self.load_animation('Graphics/Guard/Idle/Idle_Bottom',(15,15,15,15))
        
        self.animation_database['GWalkFBottom'] = self.load_animation('Graphics/Guard/Walking/Running Forward/Running_Bottom',(10,10,10,10,10,10,10,10))
        self.animation_database['GWalkLBottom'] = self.load_animation('Graphics/Guard/Walking/Running Left/Slide_Left_Bottom',(5,5))
        self.animation_database['GWalkRBottom'] = self.load_animation('Graphics/Guard/Walking/Running Right/Slide_Right_Bottom',(5,5))
        self.animation_database['GWalkBBottom'] = self.load_animation('Graphics/Guard/Walking/Running Backward/Running_Backwards_Bottom',(5,5))

        self.animation_database['GIdleTop'] = self.load_animation('Graphics/Guard/Idle/Idle_Top',(15,15,15,15))
        self.animation_database['GWalkTop'] = self.load_animation('Graphics/Guard/Walking/Running_Top',(10,10,10,10,10,10,10,10))    

        self.player_action = {
            'top' : {
                'action':"GWalkTop",
                'frame':0
            },
            'bottom':{
                'action':'GWalkFBottom',
                'frame':0
            }
        }
        
    def update_player_animation(self,part):
        self.player_action[part]['frame'] += 1
        if self.player_action[part]['frame'] >= len(self.animation_database[self.player_action[part]['action']]):
            self.player_action[part]['frame'] = 0
        player_img_id = self.animation_database[self.player_action[part]['action']][self.player_action[part]['frame']]
        player_img = animation_frames[player_img_id]
        return player_img