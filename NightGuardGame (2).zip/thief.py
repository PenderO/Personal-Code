import pygame

class Thief