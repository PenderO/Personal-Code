import pygame

class Keyhandler:
    
    def __init__(self):
        self.keyuplist = []
        self.keydownlist = []
    
    def readkeydown(self,event):
        self.keydownlist = []
        if event.key == pygame.K_d:
            self.keydownlist.append('d')
        if event.key == pygame.K_a:
            self.keydownlist.append('a')
        if event.key == pygame.K_w:
            self.keydownlist.append('w')
        if event.key == pygame.K_s:
            self.keydownlist.append('s')
        if event.key == pygame.K_SPACE:
            self.keydownlist.append('space')
        if event.key == pygame.K_UP:
            pass
        if event.key == pygame.K_DOWN:
            pass
        return self.keydownlist
            
    def readkeyup(self,event):
        self.keyuplist = []
        if event.key == pygame.K_d:
            self.keyuplist.append('d')
        if event.key == pygame.K_a:
            self.keyuplist.append('a')
        if event.key == pygame.K_w:
            self.keyuplist.append('w')
        if event.key == pygame.K_s:
            self.keyuplist.append('s')
        if event.key == pygame.K_SPACE:
            self.keyuplist.append('space')
        return self.keyuplist