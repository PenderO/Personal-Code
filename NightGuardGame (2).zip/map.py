import pygame
from settings import *
from mapconstants import *
from utilities import *

class Map:
    def __init__(self):
        self.game_map = other_load_map('mapfile')
        self.path = 'Graphics/Tiles/'
        self.floor_img = pygame.image.load(self.path + 'Tile 32 Tile-1.png.png').convert_alpha()
        self.wall_img = pygame.image.load(self.path + 'Wall 32 Tile-1.png.png').convert_alpha()

            
    def has_wall_at(self,x,y):
        return self.game_map[int(y//TILESIZE)][int(x//TILESIZE)]

    def render(self,screen):
        for i in range(len(self.game_map)):
            for j in range(len(self.game_map[i])):
                #pixel coords
                tile_x = j * TILESIZE
                tile_y = i * TILESIZE
                
                if int(self.game_map[i][j]) == 0:
                    screen.blit(self.floor_img,(tile_x-scroll[0],tile_y-scroll[1]))
                elif int(self.game_map[i][j]) == 1:
                    screen.blit(self.wall_img,(tile_x-scroll[0],tile_y-scroll[1]))