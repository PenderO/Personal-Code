import pygame
from settings import *
from ray import Ray

class Raycaster:
    def __init__(self,player,map):
        self.player = player
        self.map = map
        
    def castAllRays(self):
        self.rays = []
        self.endpoints = []
        rayAngle = (self.player.top_angle - self.player.FOV/2)
        for i in range(NUM_RAYS):
            ray = Ray(rayAngle,self.player,self.map)
            endpoint = ray.cast()
            self.rays.append(ray)
            self.endpoints.append((endpoint[0]-scroll[0],endpoint[1]-scroll[1]))
            rayAngle += self.player.FOV / NUM_RAYS
        self.endpoints.append((self.player.x-scroll[0],self.player.y-scroll[1]))
        return self.endpoints