import math,pygame
from settings import *
from utilities import *


class Shade:
    def __init__(self):
        self.distance_outer = 100
        self.distance_inner = 10
        self.step = 5
        self.max_alpha = 255
    def createMask(self,points,x,y,scroll):
        mask_surf = pygame.Surface((WINDOW_WIDTH,WINDOW_HEIGHT), pygame.SRCALPHA)
        mask_surf.fill((0, 0, 0, 255)) #color + transparency of shade
        for r in range(self.distance_outer, self.distance_inner, -self.step):
            alpha_ratio = (r - self.distance_inner) / (self.distance_outer - self.distance_inner)
            current_alpha = int(alpha_ratio * self.max_alpha)
            pygame.draw.circle(mask_surf, (0, 0, 0, current_alpha), (x-scroll[0], y-scroll[1]), r)

            pygame.draw.polygon(mask_surf, (0, 0, 0, current_alpha), points) #unshades the wanted poly

            for i in range(1):
                del points[0]
                del points[len(points)-2]

            
        return mask_surf
    
    def rendershade(self,screen,points,x,y,scroll):
        mask = self.createMask(points,x,y,scroll)
        screen.blit(mask, (0, 0))