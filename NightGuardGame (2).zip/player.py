import math, pygame
from settings import *
from utilities import *
from mapconstants import *
from anim import Animations

class Player:
    def __init__(self,map):
        self.map = map
        self.x = WINDOW_WIDTH / 2   #Starting Pos
        self.y = WINDOW_HEIGHT / 2  #
        self.radius = 3
        self.move_speed = 0.5
        self.rotationSpeed = 1 * (math.pi/180)
        self.move_right = False
        self.move_left = False  
        self.move_up = False    
        self.move_down = False  
        self.shoot = False
        self.d = 'd'            
        self.a = 'a'            
        self.w = 'w'            
        self.s = 's'    
        self.space = 'space'
        self.FOV = FOV
        self.top_angle = 0
        self.bottom_angle = 0
        self.counter = 0
        #self.shoot_counter = 0
        self.anim = Animations()
        self.anim.init_animation()

    def update(self,kulist,kdlist):

        self.counter += 0.1
        if self.counter > 7:
            self.counter = 0
        self.copycounter = int(self.counter)
        
        self.turnDirection = 0
        self.walkDirection = 0
        self.direction_vector = pygame.math.Vector2(0, 0)
        self.FOV = 80 * (math.pi / 180)
       
    #Movement 
        if self.d in kdlist:
            self.move_right = True
        if self.a in kdlist:
            self.move_left = True
        if self.w in kdlist:
            self.move_up = True
            scaleconstant = 5
        if self.s in kdlist:
            self.move_down = True
        '''if self.space in kdlist:
            self.shoot = True
            #self.FOV = 360 * (math.pi / 180)
            self.shoot_counter = 1'''
            
        if self.d in kulist:
            self.move_right = False
        if self.a in kulist:
            self.move_left = False
        if self.w in kulist:
            self.move_up = False
        if self.s in kulist:
            self.move_down = False
        '''if self.space in kulist:
            self.shoot = False'''
        
    #Collision
        if self.move_right == True and not self.map.has_wall_at(self.x+self.move_speed,self.y):
            self.direction_vector.x = 1
        if self.move_left == True and not self.map.has_wall_at(self.x-self.move_speed,self.y):
            self.direction_vector.x = -1
        if self.move_up == True and not self.map.has_wall_at(self.x,self.y-self.move_speed):
            self.direction_vector.y = -1
        if self.move_down == True and not self.map.has_wall_at(self.x,self.y+self.move_speed):
            self.direction_vector.y = 1
        #if self.shoot == True:
        '''if self.shoot_counter>0:
            self.FOV = 360 * (math.pi / 180)
            self.shoot_counter += 1
        if self.shoot_counter>=7:
            self.shoot_counter = 0'''

        self.velocity,self.move_angle = self.direction_vector.as_polar()
        self.move_angle = normalizeDegree(self.move_angle)


        mousepos = pygame.mouse.get_pos()
        mousetruex = mousepos[0]/scale_constant + scroll[0]
        mousetruey = mousepos[1]/scale_constant + scroll[1]
        
        mouse_x, mouse_y = pygame.mouse.get_pos()


        rel_x, rel_y = mousetruex - self.x, mousetruey - self.y
        
        self.top_angle = math.atan2(rel_y, rel_x)

        self.rel_head_angle = normalizeDegree(self.top_angle*(180/math.pi)-self.move_angle)

        if self.velocity > 0:
            self.direction_vector.scale_to_length(self.move_speed)
            #self.velocity = self.move_speed
            #print(self.velocity)
            self.anim.player_action['top']['action'] = 'GWalkTop'
            if self.rel_head_angle<=60 or self.rel_head_angle>=300:
                self.anim.player_action['bottom']['action'] = 'GWalkFBottom'
            elif self.rel_head_angle<=120 and self.rel_head_angle>60:
                self.anim.player_action['bottom']['action'] = 'GWalkLBottom'
            elif self.rel_head_angle>=240 and self.rel_head_angle<300:
                self.anim.player_action['bottom']['action'] = 'GWalkRBottom'
            else:
                self.anim.player_action['bottom']['action'] = 'GWalkBBottom'
        else:
            self.anim.player_action['top']['action'] = 'GIdleTop'
            self.anim.player_action['bottom']['action'] = 'GIdleBottom'
            
        self.x+=self.direction_vector.x
        self.y+=self.direction_vector.y



        self.top_img = self.anim.update_player_animation('top')
        self.bottom_img = self.anim.update_player_animation('bottom')

    def render(self,screen):
        pygame.draw.circle(screen,(255,0,0),(self.x-scroll[0],self.y-scroll[1]),self.radius)
        
        self.bottom_img = rotate_img(screen,self.bottom_img,self.move_angle*-1-90,self.x-scroll[0],self.y-scroll[1])
        screen.blit(self.bottom_img[0],self.bottom_img[1])
        self.top_img = rotate_img(screen,self.top_img,self.top_angle*-1*(180/math.pi)-90,self.x-scroll[0],self.y-scroll[1])
        screen.blit(self.top_img[0],self.top_img[1])

        #pygame.draw.line(screen,(255,0,0),(self.x-scroll[0],self.y-scroll[1]),(self.x-scroll[0]+math.cos(self.top_angle)*50,self.y-scroll[1]+math.sin(self.top_angle)*50))